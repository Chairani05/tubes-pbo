/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketkereta.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

import tiketkereta.config.Koneksi;

/**
 *
 * @author ASUS
 */
public class TransaksiDAO {
      public static void simpanTransaksi(
        String jurusan, String jenis, int harga,
        String nomorKursi, String namaPenumpang,
        int jumlahBeli, int totalBayar, int uangBayar, int uangKembali
    ) throws Exception {
        String sql = "INSERT INTO transaksi_tiket (jurusan, jenis_kelas, harga, nomor_kursi, nama_penumpang, jumlah_beli, total_bayar, uang_bayar, uang_kembali, waktu_transaksi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = Koneksi.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        
        ps.setString(1, jurusan);
        ps.setString(2, jenis);
        ps.setInt(3, harga);
        ps.setString(4, nomorKursi);
        ps.setString(5, namaPenumpang);
        ps.setInt(6, jumlahBeli);
        ps.setInt(7, totalBayar);
        ps.setInt(8, uangBayar);
        ps.setInt(9, uangKembali);
        ps.setString(10, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        
        ps.executeUpdate();
    }
}

