/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketkereta.configjava;
        

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ASUS
 */
public class Koneksi {

    private static Connection connection;

    public static Connection getConnection() {
        try {
            if (connection == null) {
                String url = "jdbc:mysql://localhost:3306/penjualan_tiket?serverTimezone=Asia/Jakarta";
                String user = "root"; // ganti sesuai user MySQL kamu
                String pass = "";     // ganti jika pakai password
                Class.forName("com.mysql.cj.jdbc.Driver"); // driver MySQL terbaru
                connection = DriverManager.getConnection(url, user, pass);
                System.out.println("Koneksi ke database berhasil.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Koneksi GAGAL!");
        }

        return connection;
    }
}
