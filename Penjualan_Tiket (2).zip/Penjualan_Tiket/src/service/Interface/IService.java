/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service.Interface;
import java.util.List;
/**
 *
 * @author ASUS
 */
public interface IService<T> {
    boolean insert(T obj);
    boolean update(T obj);
    boolean delete(int id);
    T getById(int id);
    List<T> getAll();
}
