package penjualan_tiket;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmTransaksi extends javax.swing.JFrame {

    DefaultTableModel model;

    public frmTransaksi() {
        initComponents();
        setLocationRelativeTo(null);
        model = (DefaultTableModel) tblTransaksi.getModel();
        tampilkanData();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblTransaksi = new javax.swing.JTable();
        btnRefresh = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        btnExportPDF = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Data Transaksi Tiket");

        tblTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "ID", "Jurusan", "Kelas", "Harga", "Kursi", "Nama", "Jumlah", "Total", "Bayar", "Kembali", "Tanggal"
            }
        ));
        jScrollPane2.setViewportView(tblTransaksi);

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(evt -> tampilkanData());

        btnKeluar.setText("Keluar");
        btnKeluar.addActionListener(evt -> {
            this.dispose();
            new FrmHomePage().setVisible(true);
        });

        btnExportPDF.setText("Export PDF");
        btnExportPDF.addActionListener(evt -> exportToPDF());

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnRefresh)
                        .addGap(18, 18, 18)
                        .addComponent(btnExportPDF)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 100, Short.MAX_VALUE)
                        .addComponent(btnKeluar)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(230, 230, 230))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRefresh)
                    .addComponent(btnKeluar)
                    .addComponent(btnExportPDF))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }

    private void tampilkanData() {
        DefaultTableModel model = (DefaultTableModel) tblTransaksi.getModel();
        model.setRowCount(0);

        try {
            Connection conn = tiketkereta.config.Koneksi.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM transaksi_tiket");

            while (rs.next()) {
                Object[] row = new Object[] {
                    rs.getInt("id_transaksi"),
                    rs.getString("jurusan"),
                    rs.getString("jenis_kelas"),
                    rs.getInt("harga"),
                    rs.getString("nomor_kursi"),
                    rs.getString("nama_penumpang"),
                    rs.getInt("jumlah_beli"),
                    rs.getInt("total_bayar"),
                    rs.getInt("uang_bayar"),
                    rs.getInt("uang_kembali"),
                    rs.getString("waktu_transaksi")
                };
                model.addRow(row);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal tampilkan data: " + e.getMessage());
        }
    }

    private void exportToPDF() {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("DataTransaksi.pdf"));
            document.open();

            Paragraph title = new Paragraph("DATA TRANSAKSI TIKET");
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph(" "));

            PdfPTable table = new PdfPTable(tblTransaksi.getColumnCount());
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);
            table.setWidths(new float[]{1f, 2f, 2f, 2f, 1.5f, 2f, 1.2f, 2f, 2f, 2f, 3f});

            for (int i = 0; i < tblTransaksi.getColumnCount(); i++) {
                PdfPCell headerCell = new PdfPCell(new Phrase(tblTransaksi.getColumnName(i)));
                headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                headerCell.setPadding(5);
                table.addCell(headerCell);
            }

            for (int row = 0; row < tblTransaksi.getRowCount(); row++) {
                for (int col = 0; col < tblTransaksi.getColumnCount(); col++) {
                    Object value = tblTransaksi.getValueAt(row, col);
                    PdfPCell dataCell = new PdfPCell(new Phrase(value == null ? "" : value.toString()));
                    dataCell.setPadding(5);
                    dataCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    table.addCell(dataCell);
                }
            }

            document.add(table);
            document.close();

            JOptionPane.showMessageDialog(this, "Data berhasil diexport ke DataTransaksi.pdf");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Export gagal: " + e.getMessage());
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new frmTransaksi().setVisible(true));
    }

    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnExportPDF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblTransaksi;
}